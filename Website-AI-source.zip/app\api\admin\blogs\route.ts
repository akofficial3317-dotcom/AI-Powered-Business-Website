import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getAdminUser } from "@/lib/admin-auth"

export async function GET() {
  try {
    const blogs = await prisma.blog.findMany({
      orderBy: { createdAt: "desc" },
    })

    return NextResponse.json(
      blogs.map((blog) => ({
        ...blog,
        excerpt: blog.description,
        coverImage: blog.image,
        author: {
          name: "Admin",
          email: "admin@nexa.local",
        },
      }))
    )
  } catch (error) {
    console.error("Error fetching blogs:", error)
    return NextResponse.json({ error: "Failed to fetch blogs" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const admin = await getAdminUser()
    if (!admin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { title, slug, content, excerpt, coverImage, category, published } = await request.json()

    if (!title || !slug || !content) {
      return NextResponse.json(
        { error: "Title, slug, and content are required" },
        { status: 400 }
      )
    }

    const existingSlug = await prisma.blog.findUnique({ where: { slug } })
    if (existingSlug) {
      return NextResponse.json({ error: "Slug already exists" }, { status: 400 })
    }

    const blog = await prisma.blog.create({
      data: {
        title,
        slug,
        description: excerpt || content.slice(0, 160),
        content,
        image: coverImage || null,
        category: category || "General",
        published: published ?? false,
      },
    })

    return NextResponse.json(blog, { status: 201 })
  } catch (error) {
    console.error("Error creating blog:", error)
    return NextResponse.json({ error: "Failed to create blog" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const admin = await getAdminUser()
    if (!admin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { id, title, slug, content, excerpt, coverImage, category, published } = await request.json()

    const blog = await prisma.blog.update({
      where: { id: Number(id) },
      data: {
        title,
        slug,
        description: excerpt || content?.slice(0, 160),
        content,
        image: coverImage || null,
        category: category || "General",
        published,
      },
    })

    return NextResponse.json(blog)
  } catch (error) {
    console.error("Error updating blog:", error)
    return NextResponse.json({ error: "Failed to update blog" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const admin = await getAdminUser()
    if (!admin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Blog ID required" }, { status: 400 })
    }

    await prisma.blog.delete({ where: { id: Number(id) } })

    return NextResponse.json({ message: "Blog deleted" })
  } catch (error) {
    console.error("Error deleting blog:", error)
    return NextResponse.json({ error: "Failed to delete blog" }, { status: 500 })
  }
}
