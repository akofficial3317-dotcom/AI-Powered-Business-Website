"use client"

import { motion } from "framer-motion"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { ChatWidget } from "@/components/chatbot/chat-widget"
import { TopicPhoto } from "@/components/topic-photo"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Calendar, Clock, ArrowLeft, Share2, Linkedin, Twitter, Facebook } from "lucide-react"
import { use } from "react"

// Mock blog data
const blogPosts: Record<string, {
  id: number
  title: string
  description: string
  content: string
  category: string
  createdAt: string
  readTime: string
  author: { name: string; role: string }
}> = {
  "future-of-ai-business-2024": {
    id: 1,
    title: "The Future of AI in Business: Trends to Watch in 2024",
    description: "Explore the emerging AI technologies that are reshaping how businesses operate and compete in the digital age.",
    content: `
      <p>Artificial Intelligence has moved beyond the realm of science fiction to become a crucial component of modern business strategy. As we navigate through 2024, several key trends are shaping how organizations leverage AI to gain competitive advantages.</p>

      <h2>1. Generative AI Goes Mainstream</h2>
      <p>The explosion of generative AI tools has democratized access to powerful content creation capabilities. Businesses are now using these tools for everything from marketing copy to code generation, dramatically reducing time-to-market for new initiatives.</p>

      <h2>2. AI-Powered Customer Experience</h2>
      <p>Customer expectations continue to rise, and AI is the key to meeting them. Intelligent chatbots, personalization engines, and predictive service tools are becoming table stakes for businesses serious about customer satisfaction.</p>

      <h2>3. Edge AI and Real-Time Processing</h2>
      <p>The need for instant decision-making is driving AI processing closer to the data source. Edge AI enables real-time analytics and actions without the latency of cloud communication, opening new possibilities in manufacturing, retail, and healthcare.</p>

      <h2>4. Responsible AI and Governance</h2>
      <p>As AI becomes more pervasive, organizations are implementing robust governance frameworks. Ethical AI practices, bias detection, and transparent decision-making are no longer optional—they're business imperatives.</p>

      <h2>5. AI-Human Collaboration</h2>
      <p>The most successful AI implementations augment human capabilities rather than replace them. This collaborative approach leads to better outcomes and higher adoption rates across organizations.</p>

      <h2>Looking Ahead</h2>
      <p>The businesses that thrive in this AI-driven era will be those that embrace these trends while maintaining focus on their core mission and values. The technology is powerful, but it's the human vision and strategy that ultimately determines success.</p>
    `,
    category: "AI Trends",
    createdAt: "2024-01-15",
    readTime: "8 min read",
    author: { name: "Dr. Alexandra Chen", role: "CEO & Founder" },
  },
  "ai-chatbots-customer-service": {
    id: 2,
    title: "How AI Chatbots Are Revolutionizing Customer Service",
    description: "Discover how intelligent chatbots are transforming customer support with 24/7 availability and instant responses.",
    content: `
      <p>The customer service landscape is undergoing a dramatic transformation, driven by advances in artificial intelligence and natural language processing. AI chatbots have evolved from simple rule-based systems to sophisticated virtual assistants capable of handling complex customer interactions.</p>

      <h2>The Rise of Intelligent Chatbots</h2>
      <p>Modern AI chatbots leverage advanced NLP and machine learning to understand context, sentiment, and intent. They can handle multiple conversations simultaneously, provide instant responses 24/7, and continuously learn from each interaction.</p>

      <h2>Key Benefits for Businesses</h2>
      <p>Organizations implementing AI chatbots report significant improvements in customer satisfaction, reduced support costs, and faster resolution times. The technology also frees human agents to focus on complex issues that require empathy and creative problem-solving.</p>

      <h2>Implementation Best Practices</h2>
      <p>Successful chatbot deployments start with clear objectives and carefully designed conversation flows. Integration with existing systems, robust training data, and seamless human handoff protocols are essential for delivering exceptional customer experiences.</p>

      <h2>The Future of Customer Service</h2>
      <p>As AI technology continues to advance, we can expect even more natural and helpful customer interactions. Voice-enabled assistants, proactive service, and hyper-personalization will define the next generation of customer support.</p>
    `,
    category: "Chatbots",
    createdAt: "2024-01-10",
    readTime: "6 min read",
    author: { name: "Marcus Williams", role: "CTO" },
  },
  "data-analytics-business-intelligence": {
    id: 3,
    title: "Data Analytics: Turning Information into Business Intelligence",
    description: "Learn how modern data analytics tools can help you make better decisions and gain competitive advantages.",
    content: `
      <p>Data becomes valuable when teams can understand it, trust it, and act on it. Business intelligence brings raw information together through dashboards, reports, and clear metrics that support faster decisions.</p>

      <h2>From Raw Data to Useful Insight</h2>
      <p>Most organizations already collect useful data through websites, sales systems, support channels, and operations. The challenge is connecting that data and presenting it in a way that leaders can use every day.</p>

      <h2>Dashboards That Guide Action</h2>
      <p>A good dashboard does more than show numbers. It highlights trends, warns teams about problems, and makes performance visible across departments.</p>

      <h2>Predictive Analytics</h2>
      <p>With historical patterns, businesses can forecast demand, identify risk, estimate customer behavior, and prepare better strategies before problems become expensive.</p>

      <h2>How Nexa AI Helps</h2>
      <p>Nexa AI Systems builds analytics workflows, visual reports, and dashboard experiences that help businesses move from guesswork to confident decisions.</p>
    `,
    category: "Analytics",
    createdAt: "2024-01-05",
    readTime: "10 min read",
    author: { name: "Prof. Rajan Adhikari", role: "Data Science Mentor" },
  },
  "machine-learning-small-business": {
    id: 4,
    title: "Implementing Machine Learning in Small Businesses",
    description: "A practical guide to adopting ML solutions that don't require enterprise-level budgets or resources.",
    content: `
      <p>Machine learning is not only for large enterprises. Small businesses can use focused ML solutions to improve customer response, forecast sales, personalize marketing, and reduce repetitive work.</p>

      <h2>Start With a Real Business Problem</h2>
      <p>The best ML projects begin with a clear goal: reduce manual work, predict demand, classify inquiries, or improve customer experience. Starting small keeps the project useful and affordable.</p>

      <h2>Use the Data You Already Have</h2>
      <p>Customer inquiries, sales records, website interactions, and support messages can become training signals for practical AI systems.</p>

      <h2>Keep the First Model Simple</h2>
      <p>Small teams do not need complex infrastructure on day one. A simple, well-tested model connected to a useful workflow is often more valuable than an overbuilt system.</p>

      <h2>Measure Impact</h2>
      <p>Track time saved, response speed, accuracy, and business outcomes. These metrics show whether the ML solution is truly helping.</p>
    `,
    category: "Machine Learning",
    createdAt: "2024-01-01",
    readTime: "7 min read",
    author: { name: "Dr. Elena Rai", role: "Machine Learning Professor" },
  },
  "nlp-modern-business": {
    id: 5,
    title: "The Role of NLP in Modern Business Applications",
    description: "Understanding how Natural Language Processing is enabling new ways of human-computer interaction.",
    content: `
      <p>Natural Language Processing helps software understand, classify, summarize, and respond to human language. It powers chatbots, search tools, document automation, and customer support systems.</p>

      <h2>Better Customer Conversations</h2>
      <p>NLP allows chatbots to understand intent, detect context, and respond naturally. This makes support faster and more available without removing human escalation.</p>

      <h2>Document and Message Automation</h2>
      <p>Businesses can use NLP to summarize long messages, classify inquiries, extract key details, and route tasks to the right team.</p>

      <h2>Search and Knowledge Access</h2>
      <p>Modern NLP improves internal knowledge bases by helping teams ask questions naturally and find relevant answers quickly.</p>

      <h2>Practical Implementation</h2>
      <p>Nexa AI Systems applies NLP through customer assistants, admin tools, and automation workflows that match each business's content and process.</p>
    `,
    category: "AI Trends",
    createdAt: "2023-12-28",
    readTime: "9 min read",
    author: { name: "Dr. Maya Gurung", role: "NLP & Chatbot Lead" },
  },
  "automation-enterprise-operations": {
    id: 6,
    title: "Automation Best Practices for Enterprise Operations",
    description: "Strategic approaches to implementing automation that maximizes efficiency while minimizing disruption.",
    content: `
      <p>Automation works best when it improves a clear process instead of simply replacing manual steps. The goal is to reduce errors, save time, and make operations easier to manage.</p>

      <h2>Map the Workflow First</h2>
      <p>Before building automation, teams should identify inputs, approvals, repeated tasks, handoffs, and failure points. This prevents automating a broken process.</p>

      <h2>Automate High-Volume Tasks</h2>
      <p>Good candidates include data entry, email routing, report generation, status updates, document processing, and repetitive internal notifications.</p>

      <h2>Keep Humans in Control</h2>
      <p>Important decisions should include review points, audit trails, and clear escalation paths. Automation should support teams, not hide responsibility.</p>

      <h2>Improve Over Time</h2>
      <p>Measure time saved, error reduction, and user adoption. Use those results to refine the workflow and expand automation carefully.</p>
    `,
    category: "Automation",
    createdAt: "2023-12-20",
    readTime: "11 min read",
    author: { name: "Dr. Nisha Basnet", role: "Automation Consultant" },
  },
}

// Default post for unknown slugs
const defaultPost = {
  id: 0,
  title: "Article Not Found",
  description: "The requested article could not be found.",
  content: "<p>We couldn't find the article you're looking for. Please check the URL or browse our other articles.</p>",
  category: "General",
  createdAt: new Date().toISOString().split("T")[0],
  readTime: "1 min read",
  author: { name: "Nexa AI Team", role: "Content Team" },
}

export default function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const post = blogPosts[slug] || defaultPost

  return (
    <>
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-12 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-3xl mx-auto"
            >
              <Link
                href="/blog"
                className="inline-flex items-center gap-2 text-primary hover:underline mb-6"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Blog
              </Link>

              <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                {post.category}
              </span>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
                {post.title}
              </h1>

              <p className="text-lg text-muted-foreground mb-6">
                {post.description}
              </p>

              <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                    {post.author.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{post.author.name}</p>
                    <p className="text-xs">{post.author.role}</p>
                  </div>
                </div>
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {new Date(post.createdAt).toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {post.readTime}
                </span>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Featured Image Placeholder */}
        <section className="py-8">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <TopicPhoto topic={post.category} alt={`${post.title} article photo`} className="rounded-md" />
            </div>
          </div>
        </section>

        {/* Article Content */}
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <motion.article
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="prose prose-lg dark:prose-invert max-w-none
                  prose-headings:text-foreground prose-headings:font-bold
                  prose-p:text-muted-foreground prose-p:leading-relaxed
                  prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                  prose-strong:text-foreground
                  prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
                "
                dangerouslySetInnerHTML={{ __html: post.content }}
              />

              {/* Share Section */}
              <div className="mt-12 pt-8 border-t border-border">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <span className="font-medium text-foreground">Share this article:</span>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon">
                      <Twitter className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon">
                      <Linkedin className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon">
                      <Facebook className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon">
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Want to learn more about our AI solutions?
            </h2>
            <p className="text-muted-foreground mb-6">
              Schedule a free consultation with our experts today.
            </p>
            <Button asChild>
              <Link href="/contact">Get in Touch</Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
      <ChatWidget />
    </>
  )
}
