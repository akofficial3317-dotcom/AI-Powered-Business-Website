import { NextResponse } from "next/server"

import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const events = await prisma.event.findMany({
      orderBy: {
        date: "asc",
      },
    })

    return NextResponse.json(
      events.map((event) => ({
        ...event,
        coverImage: event.banner,
        endDate: event.endDate,
        eventType: event.eventType,
        availability: event.availability,
        registrationEnabled: event.registrationEnabled,
      }))
    )
  } catch (error) {
    console.error("Error fetching events:", error)

    return NextResponse.json(
      {
        error: "Failed to fetch events",
      },
      {
        status: 500,
      }
    )
  }
}
