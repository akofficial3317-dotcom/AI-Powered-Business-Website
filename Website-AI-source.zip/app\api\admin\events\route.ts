import {
  NextRequest,
  NextResponse,
} from "next/server"

import { prisma } from "@/lib/prisma"

import { getAdminUser } from "@/lib/admin-auth"

/* =========================
   GET EVENTS
========================= */

export async function GET() {
  try {
    const events =
      await prisma.event.findMany({
        orderBy: {
          date: "desc",
        },
      })

    return NextResponse.json(
      events.map((event) => ({
        ...event,
        coverImage: event.banner,
        endDate: event.endDate,
        eventType: event.eventType,
        availability: event.availability,
        registrationEnabled: event.registrationEnabled,
        published: true,
      }))
    )
  } catch (error) {
    console.error(
      "Error fetching events:",
      error
    )

    return NextResponse.json(
      {
        error:
          "Failed to fetch events",
      },
      {
        status: 500,
      }
    )
  }
}

/* =========================
   CREATE EVENT
========================= */

export async function POST(
  request: NextRequest
) {
  try {
    const admin = await getAdminUser()

    if (!admin) {
      return NextResponse.json(
        {
          error: "Forbidden",
        },
        {
          status: 403,
        }
      )
    }

    const {
      title,
      description,
      date,
      endDate,
      eventType,
      availability,
      registrationEnabled,
      location,
      banner,
      coverImage,
    } = await request.json()

    if (!title || !date) {
      return NextResponse.json(
        {
          error:
            "Title and date are required",
        },
        {
          status: 400,
        }
      )
    }

    const startDate = new Date(
      date
    )

    const finishDate = endDate
      ? new Date(
          endDate
        )
      : null

    if (finishDate && finishDate <= startDate) {
      return NextResponse.json(
        {
          error:
            "End date and time must be after start date and time",
        },
        {
          status: 400,
        }
      )
    }

    const event =
      await prisma.event.create({
        data: {
          title,

          description,

          date: startDate,

          endDate: finishDate,

          eventType: eventType || "Event",

          availability: availability || null,

          registrationEnabled:
            registrationEnabled !== false,

          location,

          banner: banner || coverImage || null,
        },
      })

    return NextResponse.json(
      event,
      {
        status: 201,
      }
    )
  } catch (error) {
    console.error(
      "Error creating event:",
      error
    )

    return NextResponse.json(
      {
        error:
          "Failed to create event",
      },
      {
        status: 500,
      }
    )
  }
}

/* =========================
   UPDATE EVENT
========================= */

export async function PUT(
  request: NextRequest
) {
  try {
    const admin = await getAdminUser()

    if (!admin) {
      return NextResponse.json(
        {
          error: "Forbidden",
        },
        {
          status: 403,
        }
      )
    }

    const {
      id,
      title,
      description,
      date,
      endDate,
      eventType,
      availability,
      registrationEnabled,
      location,
      banner,
      coverImage,
    } = await request.json()

    const startDate = new Date(
      date
    )

    const finishDate = endDate
      ? new Date(
          endDate
        )
      : null

    if (finishDate && finishDate <= startDate) {
      return NextResponse.json(
        {
          error:
            "End date and time must be after start date and time",
        },
        {
          status: 400,
        }
      )
    }

    const event =
      await prisma.event.update({
        where: {
          id: Number(id),
        },

        data: {
          title,

          description,

          date: startDate,

          endDate: finishDate,

          eventType: eventType || "Event",

          availability: availability || null,

          registrationEnabled:
            registrationEnabled !== false,

          location,

          banner: banner || coverImage || null,
        },
      })

    return NextResponse.json(
      event
    )
  } catch (error) {
    console.error(
      "Error updating event:",
      error
    )

    return NextResponse.json(
      {
        error:
          "Failed to update event",
      },
      {
        status: 500,
      }
    )
  }
}

/* =========================
   DELETE EVENT
========================= */

export async function DELETE(
  request: NextRequest
) {
  try {
    const admin = await getAdminUser()

    if (!admin) {
      return NextResponse.json(
        {
          error: "Forbidden",
        },
        {
          status: 403,
        }
      )
    }

    const {
      searchParams,
    } = new URL(request.url)

    const id =
      searchParams.get("id")

    if (!id) {
      return NextResponse.json(
        {
          error:
            "Event ID required",
        },
        {
          status: 400,
        }
      )
    }

    await prisma.event.delete({
      where: {
        id: Number(id),
      },
    })

    return NextResponse.json({
      success: true,

      message:
        "Event deleted successfully",
    })
  } catch (error) {
    console.error(
      "Error deleting event:",
      error
    )

    return NextResponse.json(
      {
        error:
          "Failed to delete event",
      },
      {
        status: 500,
      }
    )
  }
}
